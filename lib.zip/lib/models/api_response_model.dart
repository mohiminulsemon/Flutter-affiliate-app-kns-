class ApiResponse<T> {
  final int statusCode;
  final bool success;
  final String message;
  final T data;

  ApiResponse({
    required this.statusCode,
    required this.success,
    required this.message,
    required this.data,
  });

  factory ApiResponse.fromJson(
    Map<String, dynamic> json,
    T Function(dynamic json) fromDataJson,
  ) {
    return ApiResponse<T>(
      statusCode: json['statusCode'],
      success: json['success'],
      message: json['message'],
      data: fromDataJson(json['data']),
    );
  }
}
