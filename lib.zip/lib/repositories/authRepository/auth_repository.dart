import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:knsbuy/constants/api_endpoints.dart';
import 'package:knsbuy/models/api_response_model.dart';
import 'package:knsbuy/models/login_response_model.dart';
import 'package:knsbuy/services/dio_client.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  final dio = ref.read(apiProvider);
  return AuthRepository(dio);
});

class AuthRepository {
  final DioClient dioClient;

  AuthRepository(this.dioClient);

  Future<ApiResponse<LoginData>> login({
    required String email,
    required String password,
  }) async {
    final response = await dioClient.post(
      ApiEndpoints.login,
      data: {'email': email, 'password': password},
    );

    return ApiResponse<LoginData>.fromJson(
      response.data,
      (json) => LoginData.fromJson(json),
    );
  }
}
